/**
 * Members for Caldera Forms
 * https://CalderaWP.com/downloads/cf-members
 *
 * Copyright (c) 2016 Josh Pollock for CalderaWP LLC
 * Licensed under the GPLv2+ license.
 */
 
( function( window, undefined ) {
	'use strict';
    jQuery( document ).ready( function ( $ ) {

    } );

} )( this );
